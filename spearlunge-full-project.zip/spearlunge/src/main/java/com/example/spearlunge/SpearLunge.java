package com.example.spearlunge;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;

public class SpearLunge implements ClientModInitializer {
    static final double BOOST = 1.5;
    static final int COOLDOWN = 10;
    static int cd = 0;
    static boolean enabled = true;

    static boolean isSpear(ItemStack s) {
        var key = BuiltInRegistries.ITEM.getKey(s.getItem());
        String path = key.getPath();
        // Minecraft 1.21.11 uses the item id "spear"; allow namespaced modded spears too.
        return path.equals("spear") || path.endsWith("_spear");
    }

    @Override
    public void onInitializeClient() {
        KeyMapping toggle = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.spearlunge.toggle", InputConstants.Type.KEYSYM,
            InputConstants.KEY_R, KeyMapping.Category.MISC));
        KeyMapping swapLunge = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.spearlunge.swaplunge", InputConstants.Type.KEYSYM,
            InputConstants.KEY_V, KeyMapping.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            if (cd > 0) cd--;
            if (c.player == null || c.gameMode == null) return;

            while (toggle.consumeClick()) {
                enabled = !enabled;
                c.player.displayClientMessage(
                    Component.literal("Spear Lunge: " + (enabled ? "ON" : "OFF")), true);
            }

            while (swapLunge.consumeClick()) {
                if (!enabled) continue;
                for (int i = 0; i < 9; i++) {
                    if (isSpear(c.player.getInventory().getItem(i))) {
                        c.player.getInventory().setSelectedSlot(i);
                        c.gameMode.useItem(c.player, InteractionHand.MAIN_HAND);
                        break;
                    }
                }
            }
        });

        UseItemCallback.EVENT.register((player, level, hand) -> {
            if (!enabled || !level.isClientSide() || cd > 0) return InteractionResult.PASS;
            if (!isSpear(player.getItemInHand(hand))) return InteractionResult.PASS;
            player.setDeltaMovement(player.getDeltaMovement().add(player.getLookAngle().scale(BOOST)));
            cd = COOLDOWN;
            return InteractionResult.PASS;
        });
    }
}
